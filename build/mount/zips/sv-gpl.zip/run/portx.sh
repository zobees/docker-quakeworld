#!/bin/sh
while true ; do
  NQUAKESV_RUN_MVDSV
done
#end of script
