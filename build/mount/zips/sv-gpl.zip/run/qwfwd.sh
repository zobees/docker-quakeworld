#!/bin/sh
cd qwfwd
while true ; do
./qwfwd.bin
done
#end of script