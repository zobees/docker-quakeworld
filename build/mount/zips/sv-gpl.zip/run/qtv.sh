#!/bin/sh
cd qtv
while true ; do
./qtv.bin +exec qtv.cfg
done
#end of script