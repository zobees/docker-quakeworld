#!/bin/bash

cd NQUAKESV_PATH
